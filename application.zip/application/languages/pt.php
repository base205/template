<?php

return array(

    'Home' => 'Iniciação',

    'Hot Software' => 'Hot Software',

    'New Software' => 'Nuevo Software',

    'CATEGORIES' => 'CATEGORIAS',

    'Download' => 'Baixar',

    'DOWNLOAD' => 'BAIXAR',

    'Top Downloads' => 'Mais Baixados',

    'TOP DOWNLOADS' => 'MAIS BAIXADOS',

    'Top Searches' => 'Top Búsquedas',

    'Click here Download' => 'CLIQUE AQUI PARA BAIXAR',

    'Software Details' => 'Informações sobre o programa',

    'Sorry, no software found in this category' => 'Desculpe , nenhum software nesta categoria',

    'No software found with the search chriteria' => 'Não foi encontrado um software que procurar critérios',

    'Maybe you are interested in this software' => 'Talvez você possa estar interessado neste software',

    'Free Download' => 'Download grátis',

    'Free and safe download' => 'Download seguro e livre',

    '100% SAFE DOWNLOAD' => '100% Download Secure',

    'SOFTWARE REVIEW' => 'DETALHES DE SOFTWARE',

    'Software Specs' => 'Óculos',

    'Rating' => 'Nota',

    'Not Good' => 'Malo',

    'Not Bad' => 'Regular',

    'Good' => 'Bom',

    'Very Good' => 'Muito bem',

    'Excellent' => 'Excelente',

    'Essential' => 'Essencial',

    'License' => 'Licença',

    'Language' => 'Língua',

    'SO' => 'SO',

    'Version' => 'Versão',

    'Downloads' => 'Transferências',

    'Size' => 'Tamanho',

    'Developer' => 'Revelador',

    'This Software is Virus Free!' => 'O software é livre de vírus!',

    '100% Virus-free' => '100% Virus Free',

    '100% Free Download' => '100% download grátis',

    '100% Available' => '100% Disponível',

    '100% free' => '100% Livre',

    'Download Now' => 'Baixe agora',

    'Additional Software Info' => 'Informações adicionais',

    'Will start in few seconds' => 'Ele vai começar em poucos segundos',

    'Password' => 'Senha',

    'Synchronize' => 'Sincronizar',

    'Password is invalid' => 'A chave é inválido',

    'CONTACT_US_MAIL' => 'Email de contacto',

    'CONTACT_USER' => 'Usuário',

    'CONTACT_USER_MAIL' => 'Email',

    'CONTACT_US_SUBJECT' => 'Negócio',

    'CONTACT_US_QUERY' => 'Consulta',

    'NAME' => 'Nome',

    'MAIL' => 'Email',

    'MESSAGE' => 'Mensagem',

    'SUBJECT' => 'Negócio',

    'SUBMIT' => 'Enviar',

    'MAIL_SENT_SUCCESS' => 'Envio bem-sucedido',

    'CONTACT_FORM' => 'Contacto',

    'PROBLEMS_MAIL' => 'Email de problemas',

    'PROBLEMS_ISSUE' => 'Edição',

    'PROBLEMS_MESSAGE' => 'Mensagem',

    'PROBLEMS_FORM' => '¿Problemas com a instalação ?',

    'Your download will start in' => 'Seu download começará em',

    'seconds...' => 'segundos...',

    'If the download does not start, please' => 'Se o download não iniciar, por favor',

    'click here' => 'Clique aqui',

    'Google Chrome Download' => 'Descarga de Google Chrome',

    'Mozilla Firefox Download' => 'Descarga de Mozilla Firefox',

    'Internet Explorer Download' => 'Descarga de Internet Explorer',

    'Click on' => 'Clique em',

    'at the bottom of the page.' => 'na parte inferior da página.',

    'Click "Yes" at the bottom of the page.' => 'Clique em "corrida" en la parte de abajo de la página.',

    'Click "Save" button.' => 'Clique no botão "Salvar".',

    'Click "Run".' => 'Clique em "corrida".',

    'When the download is complete double click on it.' => 'Quando o download estiver concluído, clique duas vezes sobre ele.',

    'Preparing your installation.' => 'Preparando a instalação.',

    'Click "Accept" and continue the process to complete the download.' => 'Clique em " OK" e continuar o processo para concluir o download.',

    'NO_SEARCH_RESULTS_FOR' => 'Nenhum resultado de pesquisa para',

    'MAKE_SURE_THAT_EVERYTHING_IS' => 'Certifique-se de que tudo é',

    'SPELLED_CORRECTLY' => 'escritas corretamente',

    'TRY_TO_USE' => 'tente usar',

    'DIFERENT_OR_MORE_GENERAL_KEYWORDS' => 'palavras diferentes ou mais gerais',

    'MAYBE_YOU_ARE_INTERESTED_IN_THESE' => 'Você pode estar interessado neste',

    'RECOMENDED SOFTWARE' => 'software recomendando',

    'SOFTWARE NO FOUND IN CATEGORY' => 'Não foi encontrado software nesta categoria',

    'THE SOFTWARE IS NOT FOUND' => 'Nada software encontrado',

    'Snippet not found' => 'Nada Snippet encontrado',

    'Synchronization process' => 'Processo de sincronização',

    'You have searched for' => 'Você Procurou',

    'on www.google.com' => 'em www.google.com',

    'SEARCH_RESULTS_FOR' => 'Resultados da pesquisa',

    'TOTAL DOWNLOADS' => 'Total de downloads',

    'THANK YOU PAGE' => 'Obrigado por baixar',

    'THANK YOU FOR YOUR DOWNLOAD' => '¡Obrigado por seu download!',

    'Sort By' => 'Ordenar por',

    'There is no data with this filters' => 'Não há dados para esses filtros',

    'Follow these steps to install' => 'Siga estes passos para instalar',

    'Thanks for downloading' => '¡Obrigado por baixar!',

    'ISSUE' => 'Edição',

    "I can't open the downloaded file" => "Não posso abrir o arquivo baixado",

    'Antivirus issue' => 'Problema com antivírus',

    "Operating System's issue" => "Problema com o sistema operacional",

    'Another issue' => 'Outro problema',

    'Click on software_installer.exe' => 'Click em "software_installer.exe"',

    'Click on Save' => 'Clique em "Salvar"',

    'and Click On Top Right'=> 'y Clique acima à direita.',

    'Click on Yes'=>'Clique em "Sim".',

    'Content not found' => 'Conteúdo não encontrado',

    'If your download doesn’t start' => 'Se o download não começar',

    'English' => 'Inglês',

    'French' => 'Francés',

    'Go to' => 'Visita',

    'SOFTWARE FEATURES' => 'DETALHES DE SOFTWARE',

    'DOWNLOAD AGAIN' => 'Download Novo',

    'SOFTWARE IN CATEGORY' => 'SOFTWARE EN LA CATEGORÍA',

    'is not an official partner or reseller of' => ' não é um parceiro oficial ou revendedor de produtos ',

    "'s Products" => '',

    'Download Here!' => 'Baixar aquí!',

    'INSTALLATION STEPS' => 'Installation steps',

    'DOWNLOAD_AND_INSTALL' => 'Download and Install Now',

    'NOTE_NO_RESTART' => 'Note:This Update is Free and Takes Under a Minute on Broadband No Restart Required',

    'ACCEPT_INSTALL' => 'Accept and Install',

    'STEP_ONE' => 'PASO 1',

    'STEP_TWO' => 'PASO 2',

    'STEP_THREE' => 'PASO 3',

    'STEP_FOUR' => 'PASO 4',

    'CLICK_THE_BUTTON' => 'Clique no botão abaixo para iniciar a instalação',

    'CLICK_YES_RUN' => 'Clique em "Sim / Executar" quando a janela aparece',

    'CLICK_SAVE' => 'Clique em " Save File "',

    'CLICK_DWN_ABOVE' => 'Clique na pequena seta que aparece acima de descarga ',

    'CLICK_DWN_FILE' => 'Clique no arquivo baixado',

    'CLICK_YES' => 'Clique "Sim"',

    'CLICK_RUN_SAVE' => 'Clique em "Executar / Salvar " para baixar',

    'DNW_EXE' => 'Baixe o arquivo & quot; & quot; . EXE Clique para abrir o instalador.',

    'FOLLOW_INSTALLER' => 'Siga as instruções do instalador',

    'MyPCBackup' => 'Backup MyPC salva automaticamente uma cópia de seus arquivos, fotos , músicas, vídeos , documentos e muito mais. <br /> Comece a proteger seus arquivos para não perder mais.',

    'Examples of commercial offers' => 'Exemplos de ofertas comerciais',

    'is not an official partner or reseller of' => ' Não é um parceiro oficial ou revendedor',

    "'s products" => '',
	
	'ABOUT THE DOWNLOAD' => 'SOBRE O DOWNLOAD',

    'DOWNLOAD FEATURES' => 'DETALLES DE LA DESCARGA',

);