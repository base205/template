<?php
/*
   * @Package ErrorController
*/
class ErrorController extends Zend_Controller_Action
{

    private $_site;
    public function init()
    {
        $this->_site = Zend_Registry::get('site');
    }

    public function errorAction() 
    {

    if ( APPLICATION_ENV == 'development') {

        $errors = $this->_getParam('error_handler');

            if (!$errors || !$errors instanceof ArrayObject) {
                $this->view->message = 'You have reached the error page';
                return;
            }

            switch ($errors->type) {
                case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ROUTE:
                case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER:
                case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION:
                    // 404 error -- controller or action not found
                    $this->getResponse()->setHttpResponseCode(404);
                    $priority = Zend_Log::NOTICE;
                    $this->view->message = 'Page not found';
                    break;
                default:
                    // application error
                    $this->getResponse()->setHttpResponseCode(500);
                    $priority = Zend_Log::CRIT;
                    $this->view->message = 'Application error';
                    break;
            }

            // Log exception, if logger available
            if ($log = $this->getLog()) {
                $log->log($this->view->message, $priority, $errors->exception);
                $log->log('Request Parameters', $priority, $errors->request->getParams());
            }

            // conditionally display exceptions
            if ($this->getInvokeArg('displayExceptions') == true) {
                $this->view->exception = $errors->exception;
            }

            $this->view->request   = $errors->request;
            $this->_helper->layout()->disableLayout();

    } else {

        $contentModel = new Application_Model_Content();
        $softwareModel = new Application_Model_Software();
        $categoryModel = new Application_Model_Category();
        $searchModel = new Application_Model_Search();
        $bannerModel = new Application_Model_Banner();
        
        $this->view->headerBanner = $bannerModel->getBanner('content-header');
        $this->view->footerBanner = $bannerModel->getBanner('content-footer');
        $this->view->rightTopBanner = $bannerModel->getBanner('content-right-top');
        $this->view->leftBottomBanner = $bannerModel->getBanner('content-left-bottom');

        $this->view->site = $this->_site;

        $this->view->urlSite = $this->view->baseUrl();
        $this->view->featured = $softwareModel->getFeatured();
        $this->view->pages = $contentModel->getPages();
        $this->view->categories = $categoryModel->getCategories();
        $this->view->terms = $searchModel->getSearchCloud($this->_site['limit']);
        $this->view->topDownloads = $softwareModel->getTopDownloads($this->_site['limit']);

        $uri = $this->getParam('uri');
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();

        $this->_helper->layout->setLayout('home')
            ->setLayoutPath($this->_site['templatePath'] . '/layouts');
        
        $errors = $this->_getParam('error_handler');

        if (!$errors || !$errors instanceof ArrayObject) {
          $this->view->message = 'You have reached the error page';
          return;
        }

        switch ($errors->type) {
          case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ROUTE:
          case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER:
          case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION:
            // 404 error -- controller or action not found
            $this->getResponse()->setHttpResponseCode(404);

            $priority = Zend_Log::NOTICE;
            $this->view->error_code = $this->getResponse()->getHttpResponseCode();
            $contentModel = new Application_Model_Content();

            $this->view->urlSite = $this->_site['url'];
            $this->view->site = $this->_site;

            $this->view->pages = $contentModel->getPages();

            $this->renderScript('error/error-friendly.phtml');
            break;

           default:
            $this->getResponse()->setHttpResponseCode(500);
            $priority = Zend_Log::CRIT;
            $this->view->urlSite = $this->_site['url'];
            $this->view->site = $this->_site;

            $this->view->error_code = $this->getResponse()->getHttpResponseCode();
            $this->view->message = 'Application error';
            if ($log = $this->getLog()) {
            $log->log($this->view->message, $priority, $errors->exception);
            $log->log('Request Parameters', $priority, $errors->request->getParams());

            $this->renderScript('error/error-friendly.phtml');
            }

        // conditionally display exceptions
            if ($this->getInvokeArg('displayExceptions') == true) {
                $this->view->urlSite = $this->_site['url'];
                $this->view->site = $this->_site;
                $this->view->exception = $errors->exception;
            }

            $this->view->request = $errors->request;
            $this->view->error_code = $this->getResponse()->getHttpResponseCode();

            $this->renderScript('error/error-friendly.phtml');
               break;
        }

        // Log exception, if logger available
        if ($log = $this->getLog()) {
            $log->log($this->view->message, $priority, $errors->exception);
            $log->log('Request Parameters', $priority, $errors->request->getParams());
        }

        // conditionally display exceptions
        if ($this->getInvokeArg('displayExceptions') == true) {
            $this->view->exception = $errors->exception;
        }
    }
   // $this->view->request = $errors->request;
    }

  public function getLog() 
  {
    $bootstrap = $this->getInvokeArg('bootstrap');
    if (!$bootstrap->hasResource('Log')) {
      return false;
    }
    $log = $bootstrap->getResource('Log');
    return $log;
  }

}