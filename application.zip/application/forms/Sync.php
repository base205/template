<?php
class Application_Form_Sync extends Zend_Form
{

    public function init()
    {
        $translator = Zend_Registry::get('tr');
        $this->setAttrib("horizontal", true);

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $this->setName('sync');

        $password = new Zend_Form_Element_Password('password');
        $password->setLabel($translator->translate('Password'))
            ->setRequired(true)
            ->addFilter('StripTags')
            ->addFilter('StringTrim');

        $submit = new Zend_Form_Element_Submit('submit');
        $submit->setAttrib('id', 'submitbutton');


        $this->addElements(
            array(
                $password,
                $submit
            )
        );
    }
}