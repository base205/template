<?php

require_once 'Zend/Controller/Front.php';

class Application_Model_Content
{
    private $_site;
    private $_db;
    private $_baseUrl;

    public function __construct()
    {
        $this->_db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $this->_db->setFetchMode(Zend_Db::FETCH_OBJ);
        $this->_baseUrl = Zend_Controller_Front::getInstance()->getBaseUrl();

        $this->_site = Zend_Registry::get('site');
    }

    public function getPages($menu = 1)
    {
        if (($pages = Zend_Registry::get('Zend_Cache')->load('content_pages_'.$menu)) === false) {

            $sql = $this->_db->select()
                    ->from('content', array('codContent','title','uri'))
                    ->where('active = ?', '1')
                    ->where('type = ?', 'PAGE')
                    ->where('menu = ?', $menu)
                    ->order(array('position'));

            $pages = $this->_db->fetchAll($sql);
            Zend_Registry::get('Zend_Cache')->save($pages, 'content_pages_'.$menu);

        }

        return $pages;

    }

    public function getContent($codContent)
    {

        $sql = $this->_db->select()
                    ->from('content', array('title','content','uri'))
                    ->where('active = ?', '1')
                    ->where('codContent = ?', $codContent);

        $content = $this->_db->fetchRow($sql);
        
        $content->content = $this->_replaceTags($content->content);
        
        return $content;

    }

    public function getContentByUri($uri)
    {

        $sql = $this->_db->select()
                    ->from('content', array('codContent','title','content','uri'))
                    ->where('active = ?', '1')
                    ->where('uri = ?', $uri);

        if (count($this->_db->fetchAll($sql)) > 0) {
        
            $content = $this->_db->fetchRow($sql);

            $content->content = $this->_replaceTags($content->content);

            return $content;

        } else {

            return null;
        }
    }

    public function getContentBySection($section)
    {

        if (($row = Zend_Registry::get('Zend_Cache')->load('content_'.str_replace('-', '_', $section))) === false) {

            $sql = $this->_db->select()
                    ->from('content', array('content'))
                    ->where('active = ?', '1')
                    ->where('section = ?', $section);

            $row = $this->_db->fetchRow($sql);
            if ($row == null) {
                $row = (object)'';
                $row->content = Zend_Registry::get('tr')->translate('Snippet not found').": '$section'";
            } else {
                Zend_Registry::get('Zend_Cache')->save($row, 'content_'.str_replace('-', '_', $section));
            }

        }

        $row->content = $this->_replaceTags($row->content);
                
        return $row;
    }
    
    private function _replaceTags($content)
    {
        $tags = array('[SITE-URL]', '[SITE-NAME]', '[SITE-EMAIL]');
        $texts = array($this->_baseUrl, $this->_site['name'], $this->_site['mail']);
        $content = str_replace($tags, $texts, $content);
        
        return $content;
    }

}