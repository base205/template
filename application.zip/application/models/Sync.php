<?php
class Application_Model_Sync
{
    private $_db;

    public function __construct()
    {
        $this->_db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $this->_db->setFetchMode(Zend_Db::FETCH_OBJ);
    }

    public function beginSiteTransaction()
    {
        $this->_db->beginTransaction();
    }

    public function commitSiteTransaction()
    {
        $this->_db->commit();
    }

    public function rollBackSiteTransaction()
    {
        $this->_db->rollBack();
    }
    
    public function execute($sql)
    {
        if ($sql != '') {
            $this->_db->query($sql);
            return true;
        }
        
        return false;
    }
}