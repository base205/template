<?php
/*
 * @Package ContactController
*/
require_once 'Zend/Config/Ini.php';

class ContactController extends Zend_Controller_Action
{

    private $site;

    public function init()
    {
        $this->site = Zend_Registry::get('site');
    }

    public function sendMailAction()
    {

        $contentModel = new Application_Model_Content();
        $softwareModel = new Application_Model_Software();
        $categoryModel = new Application_Model_Category();
        $searchModel = new Application_Model_Search();

        $tr = Zend_Registry::get('tr');

        // Set the title
        $this->view->headTitle()->setSeparator(' - ');
        $this->view->headTitle($tr->translate('CONTACT_FORM'));
        $this->view->headTitle($this->site['name']);

        $this->view->site = $this->site;

        $this->view->featured = $softwareModel->getFeatured();
        $this->view->pages = $contentModel->getPages();
        $this->view->categories = $categoryModel->getCategories();
        $this->view->terms = $searchModel->getSearchCloud($this->site['limit']);
        $this->view->topDownloads = $softwareModel->getTopDownloads($this->site['limit']);

        $this->_helper->layout->setLayout('home')
            ->setLayoutPath($this->site['templatePath'] . '/layouts');

        $form = new Application_Form_Contact();        

        if ( $this->getRequest()->isPost() ) {

            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData['bootstrap'])) {

                $name    = $formData['bootstrap']['name'];
                $email   = $formData['bootstrap']['mail'];
                $subject = $formData['bootstrap']['subject'];
                $message = $formData['bootstrap']['message'];

                $html = '<h3>'.Zend_Registry::get('tr')
                                ->translate('CONTACT_US_MAIL').'</h3>';
                $html .= '<p>'.Zend_Registry::get('tr')
                                ->translate('CONTACT_USER').': '.$name.'</p>';
                $html .= '<p>'.Zend_Registry::get('tr')
                                ->translate('CONTACT_USER_MAIL').': '.$email.'</p>';
                $html .= '<p>'.Zend_Registry::get('tr')
                                ->translate('CONTACT_US_SUBJECT').': '. $subject .'</pre>';
                $html .= '<p>'.Zend_Registry::get('tr')
                                ->translate('CONTACT_US_QUERY').': '. $message .'</pre>';

                $mail = new Zend_Mail();
                $mail->setBodyHtml($html);
                $mail->setFrom($this->site['mail'], $this->site['name']);
                $mail->addTo($this->site['mail'], $this->site['name']);
                $mail->setSubject('Contact form: '.$subject);
                $mail->send();

                $content = $contentModel->getContentByUri('contact-us')->content;
                $this->view->content = str_replace(
                    '[CONTACT-FORM]', 
                    Zend_Registry::get('tr')->translate("MAIL_SENT_SUCCESS"), 
                    $content
                );    
            } else {
                $form->populate($formData);
                $content = $contentModel->getContentByUri('contact-us')->content;
                $this->view->content = str_replace('[CONTACT-FORM]', $form, $content);
            }
        } else {
            $content = $contentModel->getContentByUri('contact-us')->content;
            $this->view->content = str_replace('[CONTACT-FORM]', $form, $content);    
        }        
    }

    public function problemsAction()
    {
        $contentModel = new Application_Model_Content();
        $softwareModel = new Application_Model_Software();
        $categoryModel = new Application_Model_Category();
        $searchModel = new Application_Model_Search();

        $tr = Zend_Registry::get('tr');

        // Set the title
        $this->view->headTitle()->setSeparator(' - ');
        $this->view->headTitle($tr->translate('CONTACT_FORM'));
        $this->view->headTitle($this->site->name);        
        
        $uri = $this->getParam('software', '');

        $this->view->site = $this->site;

        $this->view->featured = $softwareModel->getFeatured();
        $this->view->pages = $contentModel->getPages();
        $this->view->categories = $categoryModel->getCategories();
        $this->view->terms = $searchModel->getSearchCloud($this->site->limit);
        $this->view->topDownloads = $softwareModel->getTopDownloads($this->site->limit);

        $this->_helper->layout->setLayout('home')
            ->setLayoutPath($this->site->templatePath . '/layouts');

        $form = new Application_Form_Problems();

        if ( $this->getRequest()->isPost() ) {

            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData['bootstrap'])) {

                $issue    = $formData['bootstrap']['issue'];
                $message = $formData['bootstrap']['message'];

                $html = '<h3>'.Zend_Registry::get('tr')
                                ->translate('PROBLEMS_MAIL').'</h3>';
                $html .= '<p>'.Zend_Registry::get('tr')
                                ->translate('PROBLEMS_ISSUE').': '.$issue.'</p>';
                $html .= '<p>'.Zend_Registry::get('tr')
                                ->translate('PROBLEMS_MESSAGE').': '.$message.'</p>';
                $html .= '<p>Software: '.$uri.'</p>';
                $html .= '<p>OS: '.$this->_getOS().'</p>';
                $html .= '<p>Browser: '.$this->_getBrowser().'</p>';
                $html .= '<p>Browser language: '.$_SERVER['HTTP_ACCEPT_LANGUAGE'].'</p>';

                $mail = new Zend_Mail();
                $mail->setBodyHtml($html);
                $mail->setFrom($this->site->mail, $this->site->name);
                $mail->addTo($this->site->mail, $name);
                $mail->setSubject(Zend_Registry::get('tr')->translate('PROBLEMS_MAIL'));
                $mail->send();

                $this->view->successMail = Zend_Registry::get('tr')->translate("MAIL_SENT_SUCCESS");
            } else {
                $this->view->form = $form;
                $form->populate($formData);
            }
        } else {
            $this->view->form = $form;
        }
    }
    
    private function _getOS()
    { 

        $userAgent = $_SERVER['HTTP_USER_AGENT'];

        $osPlatform    =   "Unknown OS Platform";

        $osArray       =   array(
                '/windows nt 6.2/i'     =>  'Windows 8',
                '/windows nt 6.1/i'     =>  'Windows 7',
                '/windows nt 6.0/i'     =>  'Windows Vista',
                '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                '/windows nt 5.1/i'     =>  'Windows XP',
                '/windows xp/i'         =>  'Windows XP',
                '/windows nt 5.0/i'     =>  'Windows 2000',
                '/windows me/i'         =>  'Windows ME',
                '/win98/i'              =>  'Windows 98',
                '/win95/i'              =>  'Windows 95',
                '/win16/i'              =>  'Windows 3.11',
                '/macintosh|mac os x/i' =>  'Mac OS X',
                '/mac_powerpc/i'        =>  'Mac OS 9',
                '/linux/i'              =>  'Linux',
                '/ubuntu/i'             =>  'Ubuntu',
                '/iphone/i'             =>  'iPhone',
                '/ipod/i'               =>  'iPod',
                '/ipad/i'               =>  'iPad',
                '/android/i'            =>  'Android',
                '/blackberry/i'         =>  'BlackBerry',
                '/webos/i'              =>  'Mobile'
                            );

        foreach ($osArray as $regex => $value) { 

            if (preg_match($regex, $userAgent)) {
                $osPlatform    =   $value;
            }

        }   

        return $osPlatform;

    }

    private function _getBrowser() 
    {

        $userAgent = $_SERVER['HTTP_USER_AGENT'];;

        $browser        =   "Unknown Browser";

        $browserArray  =   array(
                '/msie/i'       =>  'Internet Explorer',
                '/firefox/i'    =>  'Firefox',
                '/safari/i'     =>  'Safari',
                '/chrome/i'     =>  'Chrome',
                '/opera/i'      =>  'Opera',
                '/netscape/i'   =>  'Netscape',
                '/maxthon/i'    =>  'Maxthon',
                '/konqueror/i'  =>  'Konqueror',
                '/mobile/i'     =>  'Handheld Browser'
                            );

        foreach ($browserArray as $regex => $value) { 

            if (preg_match($regex, $userAgent)) {
                $browser    =   $value;
            }

        }

        return $browser;

    }
}