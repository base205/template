<?php
require_once 'Zend/Config/Ini.php';

class ContentController extends Zend_Controller_Action {

    private $_site;
    protected $models = array();

    public function init(){
        $this->_site = Zend_Registry::get('site');

        $this->models = array(
            'content' => new Application_Model_Content(),
            'software' => new Application_Model_Software(),
            'category' => new Application_Model_Category(),
            'search' => new Application_Model_Search()
        );
    }

    public function indexAction(){
        $this->view->content = $this->models['content']->getContentBySection($this->getParam('section'))->content;
    }

    public function pageAction(){
        $idContent = $this->getParam('id');

        $form = new Application_Form_Contact();
        $form->setAction('/contact/send-mail')->setMethod('post');
        
        $problemsForm = new Application_Form_Problems();
        $problemsForm->setAction('/contact/problems')->setMethod('post');

        $viewParams = array(
            'site' => $this->_site,
            'urlSite' => $this->_site['url'],
            'featured' => $this->models['software']->getFeatured(),
            'pages' => $this->models['content']->getPages(),
            'categories' => $this->models['category']->getCategories(),
            'terms' => $this->models['search']->getSearchCloud($this->_site['limit']),
            'topDownloads' => $this->models['software']->getTopDownloads($this->_site['limit'])
            );

        foreach($viewParams as $key => $val)
            $this->view->$key = $val;

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();

        $page = $this->models['content']->getContent($idContent);
        $content = $page->content;

        $this->view->headTitle()->setSeparator(' - ');
        $this->view->headTitle($page->title);
        $this->view->headTitle($this->_site['name']);

        $content = str_replace('[CONTACT-FORM]', $form, $content);
        $content = str_replace('[PROBLEMS-FORM]', $problemsForm, $content);

        $this->view->content = $content;
        $this->view->title = $page->title;
       

        $this->_helper->layout->setLayout('home')
                                ->setLayoutPath($this->_site['templatePath'] . '/layouts');
    }

    public function pageByUriAction(){
        $hotSoftware = $this->models['software']->getSoftwareByHot(1, $this->_site['limit']);
        $newSoftware = $this->models['software']->getSoftwareByHot(0, $this->_site['limit']);
        $this->models['banner'] = new Application_Model_Banner();

        $viewParams = array(
            'headerBanner' => $this->models['banner']->getBanner('content-header'),
            'footerBanner' => $this->models['banner']->getBanner('content-footer'),
            'rightTopBanner' => $this->models['banner']->getBanner('content-right-top'),
            'leftBottomBanner' => $this->models['banner']->getBanner('content-left-bottom'),
            'site' => $this->_site,
            'urlSite' => $this->view->baseUrl(),
            'featured' => $this->models['software']->getFeatured(),
            'pages' => $this->models['content']->getPages(),
            'categories' => $this->models['category']->getCategories(),
            'terms' => $this->models['search']->getSearchCloud($this->_site['limit']),
            'topDownloads' => $this->models['software']->getTopDownloads($this->_site['limit'])
        );

        $uri = $this->getParam('uri');
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();

        $content = $this->models['content']->getContentByUri($uri);

        foreach($viewParams as $key => $val)
            $this->view->$key = $val;

        $this->_helper->layout->setLayout('home')
                                ->setLayoutPath($this->_site['templatePath'] . '/layouts');

        if($content){
            $this->view->headTitle()->setSeparator(' - ');
            $this->view->headTitle($content->title);
            $this->view->headTitle($this->_site['name']);
                                
            $this->view->image = (file_exists(APPLICATION_PATH . '/..' . $this->_site['assetsPath'].'/img/content/'.$content->codContent.'.jpg')) ? $this->_site['assetsPath'].'/img/content/'.$content->codContent.'.jpg' : '';

            $form = new Application_Form_Contact();
            $form->setAction('/contact/send-mail')->setMethod('post');
        
            $problemsForm = new Application_Form_Problems();
            $problemsForm->setAction('/contact/problems')->setMethod('post');

            $content->content = str_replace('[CONTACT-FORM]', $form, $content->content);
            $content->content = str_replace('[PROBLEMS-FORM]', $problemsForm, $content->content);
            $this->view->hotSoftware = $hotSoftware;
            $this->view->newSoftware = $newSoftware;
            $this->view->content = $content->content;
            $this->render('page');
        } else {
            $this->render('not-found');
        }

    }

}

