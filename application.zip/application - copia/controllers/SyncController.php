<?php
/*
   * @Package ContentController
*/
require_once 'Zend/Config/Ini.php';

class SyncController extends Zend_Controller_Action
{
    private $_site;
    
    public function init()
    {
        $this->_site = Zend_Registry::get('site');
    }

    public function indexAction()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout->disableLayout();
        
        $syncModel = new Application_Model_Sync();
        $portalModel = new Application_Model_Portal();

        $syncPath = $this->_site['syncPath'];
        $imgPath = APPLICATION_PATH . '/..' .$this->_site['assetsPath'] . '/img/';
        $jsPath = APPLICATION_PATH . '/..' .$this->_site['assetsPath'] . '/js/';

        $dir = new DirectoryIterator($syncPath);

        echo '<h2>Sync</h2>';
        foreach ($dir as $fileinfo) {

            $file = $fileinfo->getFilename();
            
            if (!$fileinfo->isDot() && strpos($file, '_delete.sql') === false) {

                $module = substr($file, 0, strpos($file, '_'));

                if (substr($file, -4) == '.sql') {
                    switch ($module) {
                        case 'banner': 
                        case 'category':
                            if (file_exists($syncPath . '/' . $module . '_delete.sql')) { 
                                $sql = file_get_contents($syncPath . '/' . $module . '_delete.sql', true);
                                if (!$syncModel->execute($sql)) {
                                    echo '<p>'.$module . '_delete.sql NOT executed</p>';
                                } else {
                                    echo '<p>'.$module . '_delete.sql executed</p>';
                                }
                                unlink($syncPath . '/' . $module . '_delete.sql');
                            } 
                        case 'content':
                        case 'software':
                            $sql = file_get_contents($syncPath . '/' . $file, true);
                            if (!$syncModel->execute($sql)) {
                                echo '<p>'.$file . ' NOT executed</p>';
                            } else {
                                echo '<p>'.$file.' executed</p>';
                            }
                            unlink($syncPath.'/'.$file);
                            break;
                        case 'portal':
                            $sql = file_get_contents($syncPath . '/' . $file, true);
                            if (!$syncModel->execute($sql)) {
                                echo '<p>'.$file . ' NOT executed</p>';
                            } else {
                                echo '<p>'.$file.' executed</p>';
                            }
                            unlink($syncPath.'/'.$file);

                            //Creamos el nuevo analytics
                            $script = $portalModel->getAnalytics();
                            $fp = fopen($jsPath . 'analytics.js', 'w');
                            fwrite($fp, $script);
                            fclose($fp);
                            break;
                    }
                } else {
                    if ($module == 'banner') {
                        copy($syncPath . '/' . $file, $imgPath . 'banner/' . $file);
                        echo '<p>'.$file.' copied to '. $imgPath . 'banner/' . $file . '</p>';
                    } else {
                        //son imágenes de softwares o de contents
                        if ($module == 'content') {
                            //son capturas
                            copy($syncPath . '/' . $file, $imgPath . 'content/' . str_replace('content_', '', $file));
                            echo '<p>'.$file.' copied to '. $imgPath . 'content/' . str_replace('content_', '', $file) . '</p>';
                        } else {
                            if (substr($file, -4) == '.png') {
                                if (strpos($file, '-featured') === false) {
                                    //es el icono
                                    if(!file_exists($syncPath . '/' . $file, $imgPath . 'icon')){
                                            mkdir($syncPath . '/' . $file, $imgPath . 'icon');
                                        }

                                    copy($syncPath . '/' . $file, $imgPath . 'icon/' . $file);
                                    echo '<p>'.$file.' copied to '. $imgPath . 'icon/' . $file . '</p>';
                                } else{
                                    if(!file_exists($syncPath . '/' . $file, $imgPath . 'capture')){
                                            mkdir($syncPath . '/' . $file, $imgPath . 'capture');
                                        }
                                    //es la imagen featured
                                    copy($syncPath . '/' . $file, $imgPath . 'capture/' . $file);
                                    echo '<p>'.$file.' copied to '. $imgPath . 'capture/' . $file . '</p>';

                                }
                            } else {
                                //son capturas
                                copy($syncPath . '/' . $file, $imgPath . 'capture/' . $file);
                                echo '<p>'.$file.' copied to '. $imgPath . 'capture/' . $file . '</p>';
                            }
                        }
                    }
                    unlink($syncPath.'/'.$file);
                }
            }
        }
        
        $log = $this->_removeCache();
        echo $log;
    }
    
    public function cacheAction()
    {
        $form = new Application_Form_Sync();
        $this->view->form = $form;
        $form->submit->setLabel(Zend_Registry::get('tr')->translate('Synchronize'));

        $this->_helper->layout->disableLayout();

        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();

            $log = '<h2>Cache</h2>';
            $log .= $this->_removeCache();

            $this->view->log = $log;
            $this->_helper->layout->disableLayout();
        }

        $this->render('index');        

    }

    private function _removeCache()
    {
        $log = '<h2>Cache</h2>';
        try{
            Zend_Registry::get('Zend_Cache')->clean(Zend_Cache::CLEANING_MODE_ALL);
            $log .= '<p>Cleaning cache... Ok!</p>';
        }catch (Exception $e) {
            $log .= '<p>Cleaning cache... ERROR!</p>';
            $log .= $e->getMessage();
        }
        return $log;
    }
    	public function execqueryAction () 	{		$syncModel = new Application_Model_Sync();				if (file_exists(APPLICATION_PATH . '/../' . 'query.sql')) { 			$sql = file_get_contents(APPLICATION_PATH . '/../' . 'query.sql', true);			if (!$syncModel->execute($sql)) {				echo '<p>query.sql NOT executed</p>';			} else {				echo '<p>query.sql executed</p>';			}			unlink(APPLICATION_PATH . '/../' . 'query.sql');		} 	}
}
