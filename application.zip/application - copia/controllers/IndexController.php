<?php

/**
* @package IndexController
*/
class IndexController extends Zend_Controller_Action {

    private $_site, $models;

    public function init(){
        $this->_site = Zend_Registry::get('site');
        $this->models = array(
            'content' => new Application_Model_Content(),
            'software' => new Application_Model_Software(),
            'category' => new Application_Model_Category(),
            'search' => new Application_Model_Search(),
            'banner' => new Application_Model_Banner()
            );
    }

    public function indexAction(){
        $viewParams = array(
            'site' => $this->_site,
            'featured' => $this->models['software']->getFeatured(),
            'pages' => $this->models['content']->getPages(),
            'categories' => $this->models['category']->getCategories(),
            'searchTerms' => $this->models['search']->getSearchCloud($this->_site['limit']),
            'topDownloads' => $this->models['software']->getTopDownloads($this->_site['limit']),
            'hotSoftware' => $this->models['software']->getSoftwareByHot(1, $this->_site['limit']),
            'newSoftware' => $this->models['software']->getSoftwareByHot(0, $this->_site['limit']),
            'rightTopBanner' => $this->models['banner']->getBanner('home-right-top'),
            'rightBottomBanner' => $this->models['banner']->getBanner('home-right-bottom'),
            'leftBottomBanner' => $this->models['banner']->getBanner('home-left-bottom'),
            'headerBanner' => $this->models['banner']->getBanner('home-header'),
            'footerBanner' => $this->models['banner']->getBanner('home-footer')
            );
        $this->view->headTitle($this->_site['name']);

        // Load hot software under "Games" & "Programs" categories
        //$gamesCategory = $this->models['category']->getCategory('games');
        //$programsCategory = $this->models['category']->getCategory('antivirus'); // Test category!
//
//        //$viewParams['hotSoftwareByCategory'] = array(
//        //    'games' => array('category' => $gamesCategory, 'list' => $this->models['software']->getSoftwareByCategory($gamesCategory->idCategory, 5, null, null, 1)),
//        //    'programs' => array('category' => $programsCategory, 'list' => $this->models['software']->getSoftwareByCategory($programsCategory->idCategory, 5, null, null, 1)),
        //    );

        foreach($viewParams as $key => $value)
            $this->view->$key = $value;

        $this->_helper->layout->setLayout('home')
                                ->setLayoutPath($this->_site['templatePath'] . '/layouts');
    }

    public function sitemapAction(){
        $baseUrl = Zend_Controller_Front::getInstance()->getBaseUrl();

        $xmlOutput = array(
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        );

        foreach ($this->models['content']->getPages() as $page)
            $xmlOutput[] = "<url><loc>http://" . $baseUrl . "/content/" . $page->uri . "</loc></url>\n";

        foreach ($this->models['category']->getCategories() as $category)
            $xmlOutput[] = "<url><loc>http://" . $baseUrl . "/software/category/uri/" . $category->uri . "</loc></url>\n";

        foreach ($this->models['software']->getAllActive() as $soft)
            $xmlOutput[] = "<url><loc>http://" . $baseUrl . "/" . $soft->uri . "</loc></url>\n";

        $xmlOutput[] = '</urlset>';

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout->disableLayout();

        die(implode('', $xmlOutput));
    }

}