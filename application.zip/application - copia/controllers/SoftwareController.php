<?php
/**
* @package SoftwareController
*/
class SoftwareController extends Zend_Controller_Action {
    private $_site, $models;

    public function init(){
        $this->_site = Zend_Registry::get('site');

        
        $this->models = array(
            'content' => new Application_Model_Content(),
            'software' => new Application_Model_Software(),
            'category' => new Application_Model_Category(),
            'search' => new Application_Model_Search(),
            'portal' => new Application_Model_Portal(),
            'banner' => new Application_Model_Banner()
            );
    }

    public function indexAction(){
        // action body
        $this->view->cloud = new Zend_Tag_Cloud(
            array(
                'tags' => array(
                    array('title' => 'Code', 'weight' => 50,
                          'params' => array('url' => '/tag/code')),
                    array('title' => 'Zend Framework', 'weight' => 1,
                          'params' => array('url' => '/tag/zend-framework')),
                    array('title' => 'PHP', 'weight' => 5,
                          'params' => array('url' => '/tag/php')),
                )
            )
        );
    }

    public function viewAction(){
        $uri = $this->getParam('uri');
        $source = $this->getParam('utm_source');
        $soft = $this->models['software']->getSoftwareByUri($uri);
        $newSoftware = $this->models['software']->getSoftwareByHot(0, $this->_site['limit']);
        $softwareByCategory = $this->models['software']->getSoftwareByCategory($soft->idcategory, $this->_site['limit']);

        $viewParams = array(
            'site' => $this->_site,
            'banner' => $this->models['portal']->getBanner(),
            'pages' => $this->models['content']->getPages(),
            'categories' => $this->models['category']->getCategories(),
            'terms' => $this->models['search']->getSearchCloud($this->_site['limit']),
            'topDownloads' => $this->models['software']->getTopDownloads($this->_site['limit']),
            );

        foreach($viewParams as $key => $val)
            $this->view->$key = $val;
        
        if ( ! empty($source)) {
            $this->view->statKey = '/?ch='.$this->getParam('utm_source') .
                    '&c=' . $this->getParam('utm_campaign') . '&k=' . $this->getParam('utm_term');
            $this->view->googleQuery = $this->getParam('utm_term');
        } else {
            $this->view->statKey = '';
        }

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();


        if( ! is_null($soft) && $soft != false ){




            // Set the title
            $this->view->headTitle()->setSeparator(' - ');
            $this->view->headTitle($soft->name);
            $this->view->headTitle($this->_site['name']);

            if ( !preg_match('/http:\/\/|https:\/\//', $soft->developerWeb) ) {
                $soft->developerWeb = 'http://' . $soft->developerWeb;
            }

            $this->view->soft = $soft;
            $this->view->newSoftware = $newSoftware;
            $this->view->softwareByCategory = $softwareByCategory;
            $this->view->icon = $soft->codSoftware;
            $this->view->capture = $this->getCapture($soft->codSoftware);

            $this->view->downloadInfo = str_replace(
                '[DEVELOPER-WEB]',
                $soft->developerWeb,
                $this->models['content']->getContentBySection('DOWNLOADINFO')->content
            );
            $this->view->toolbar = $this->models['content']->getContentBySection('TOOLBAR')->content;

            if( ! empty($soft->metaDescription))
                $this->view->headMeta()->setName('description', $soft->metaDescription);

            if( ! empty($soft->metaKeywords))
                $this->view->headMeta()->setName('keywords', $soft->metaKeywords);
            
            $this->view->headerBanner = $this->models['banner']->getBanner('software-header');
            $this->view->footerBanner = $this->models['banner']->getBanner('software-footer');
            $this->view->rightBanner = $this->models['banner']->getBanner('software-right-top');

            $this->view->comments = $this->models['software']->getCommentsByCod($soft->codSoftware);
            
            //Llamamos a la apí de BO para saber si el portal y/o el país del user tienen un installer que ofrecer
            $url = $this->_site['apiUrl'] . 'get-geo' .
                '?ip='. $this->_getClientIP() .
                '&portal='. $this->_site['id'];

            $apiResult = json_decode($this->_curl(str_replace(" ", "%20", $url)));

            if ($apiResult->installer != 0) {
                //Si tienen un installer que ofrecer sigue el curso normal
                $this->view->platform = $this->_getPlatform();
            } else {
                //Si no hacemos todo lo posible por que no muestre el botón de descarga
                $this->view->platform =  array('isMobile' => true, 'isOSX' => true, 'platform' => 'Linux');
            }            

            $content = $this->models['content']->getContentByUri('terms-and-conditions');
            $this->view->terms = $content->content;

            $this->_helper->layout->setLayout('software')
                ->setLayoutPath($this->_site['templatePath'] . '/layouts');

            $this->render('view');
        } else {
            // Set the title
            $this->view->headTitle($this->_site['name']);
             $this->view->newSoftware = $newSoftware;
             $this->view->softwareByCategory = $softwareByCategory;
            $this->view->headerBanner = $this->models['banner']->getBanner('list-header');
            $this->view->footerBanner = $this->models['banner']->getBanner('list-footer');
            $this->view->rightBanner = $this->models['banner']->getBanner('list-right-top');
            $this->view->rightBottomBanner = $this->models['banner']->getBanner('list-right-bottom');
            $this->view->leftBottomBanner = $this->models['banner']->getBanner('list-left-bottom');

            $list = $this->models['software']->getSoftwareByHot(1, 5);

            $this->view->list = $list;
            $this->view->urlSite = $this->view->baseUrl();

            $this->_helper->layout->setLayout('home')
                ->setLayoutPath($this->_site['templatePath'] . '/layouts');
            $this->render('not-found');
        }
    }

    public function searchAction(){
        $search = strtolower($this->getParam('search'));
        $page=$this->getParam('page', 1);
        $hotSoftware = $this->models['software']->getSoftwareByHot(1, $this->_site['limit']);

        // Set the title
        $this->view->headTitle()->setSeparator(' - ');
        $this->view->headTitle(ucfirst($search));
        $this->view->headTitle($this->_site['name']);

        foreach(array(
            'urlSite' => $this->view->baseUrl(),
            'site' => $this->_site,
            'featured' => $this->models['software']->getFeatured(),
            'pages' => $this->models['content']->getPages(),
            'categories' => $this->models['category']->getCategories(),
            'terms' => $this->models['search']->getSearchCloud($this->_site['limit']),
            'topDownloads' => $this->models['software']->getTopDownloads($this->_site['limit']),
            'hotSoftware' => $this->models['software']->getSoftwareByHot(1, 5),
            'newSoftware' => $this->models['software']->getSoftwareByHot(0, 5),
            'orderUrl' => $this->view->baseUrl()."/software/search/search/".$this->getParam('search')."/order",
            'search' => $search,
            'headerBanner' => $this->models['banner']->getBanner('list-header'),
            'footerBanner' => $this->models['banner']->getBanner('list-footer'),
            'rightTopBanner' => $this->models['banner']->getBanner('list-right-top'),
            'rightBottomBanner' => $this->models['banner']->getBanner('list-right-bottom'),
            'leftBottomBanner' => $this->models['banner']->getBanner('list-left-bottom')
            ) as $key => $val)
            $this->view->$key = $val;

        $getorder = $this->getParam('order');

        if( ! is_null($getorder)){
            $this->view->varOrder = $getorder;
            $list = $this->models['software']->search($search, $getorder);
        } else {
            $list = $this->models['software']->search($search);
        }
        
        $this->view->hot = (count($list) === 0);

        if (count($list) === 0)
            $list = $this->models['software']->getSoftwareByHot(1, 5);
        else
            $this->models['software']->saveSearch($search);

        $paginator = Zend_Paginator::factory($list);
        $paginator->setItemCountPerPage($this->_site['limit']);
        $paginator->setCurrentPageNumber($page);
        $this->view->paginator = $paginator;
        $this->view->hotSoftware = $hotSoftware;

        $this->_helper->layout->setLayout('home')
            ->setLayoutPath($this->_site['templatePath'] . '/layouts');
    }

    /**
     * List software under category
     * @link /software/category/uri/$uri
     */
    public function categoryAction(){
        $currentPage = $this->getParam('page', 1);
        $categoryURI = $this->getParam('uri', '');
        $orderOption = $this->getParam('order');

        $category = $this->models['category']->getCategory($categoryURI);

        // Set the title
        $this->view->headTitle()->setSeparator(' - ');
        $this->view->headTitle($category->category);
        $this->view->headTitle($this->_site['name']);

        foreach(array(
            'urlSite' => $this->view->baseUrl(),
            'site' => $this->_site,
            'pages' => $this->models['content']->getPages(),
            'categories' => $this->models['category']->getCategories(),
            'terms' => $this->models['search']->getSearchCloud($this->_site['limit']),
            'topDownloads' => $this->models['software']->getTopDownloads(4),
            'rightBanner' => $this->models['banner']->getBanner('list-right-top'),
            'rightBottomBanner' => $this->models['banner']->getBanner('list-right-bottom'),
            'headerBanner' => $this->models['banner']->getBanner('list-header'),
            'footerBanner' => $this->models['banner']->getBanner('list-footer'),
            'leftBottomBanner' => $this->models['banner']->getBanner('list-left-bottom'),
            ) as $key => $val)
            $this->view->$key = $val;
        
        if ( ! is_null($category)){
            $this->view->orderUrl = $this->view->baseUrl() . '/software/category/uri/' . $categoryURI . '/order';

            if ( ! is_null($orderOption)){
                $this->view->varOrder = $orderOption;
                $software = $this->models['software']->getSoftwareByCategory($category->idCategory, 0, null, $orderOption);
            } else {
                $software = $this->models['software']->getSoftwareByCategory($category->idCategory);
            }
        } else {
            $software = array();
        }

        $this->view->category = $category;

        $paginator = Zend_Paginator::factory($software);
        $paginator->setItemCountPerPage($this->_site['limit']);
        $paginator->setCurrentPageNumber($currentPage);

        $this->view->paginator = $paginator;

        $this->_helper->layout->setLayout('home')
                                ->setLayoutPath($this->_site['templatePath'] . '/layouts');
    }

    public function downloadAction(){
        /**
         * TODO: Porque estamos cambiando los nombre de los parametros de utm_ a estto?
         *       Mantengamos la nomenclatura de los parametros entre vistas 
         *       utm_source, utm_medium, utm_campaign, utm_term
         */
        $hotSoftware = $this->models['software']->getSoftwareByHot(1, $this->_site['limit']);
        $newSoftware = $this->models['software']->getSoftwareByHot(0, $this->_site['limit']);
        
        $uri = $this->getParam('uri');
        $channel = $this->getParam('ch');
        $keyword = $this->getParam('k');
        $campaign = $this->getParam('c');

        $viewParams = array(
            'headerBanner' => $this->models['banner']->getBanner('software-header'),
            'footerBanner' => $this->models['banner']->getBanner('software-footer'),
            'bodyClass' => 'class="download"',
            'categories' => $this->models['category']->getCategories()
            );
        
        $software = $this->models['software']->getSoftwareByUri($uri);

        if( ! is_null($software)){
            $this->view->headScript()->appendFile($this->_site['assetsPath'] . '/../common/js/storage.js');
            $this->view->headTitle()->setSeparator(' - ');
            $this->view->headTitle($software->name);
            $this->view->headTitle($this->_site['name']);
            $viewParams['externalBundle'] = $software->externalBundle;
            $viewParams['externalBundleUrl'] = $software->externalBundleUrl;

            if ($this->_getOS($_SERVER['HTTP_USER_AGENT']) == "Mac OS X" ) {
                $folder = 'osx';
                $extension = 'dmg';
            } else {
                $folder = 'win';
                $extension = 'exe';
            }

            $viewParams['downloadUrl'] = 'http://offersrepo.com/download.php';
            $viewParams['downloadName'] = $uri . '.exe';
 
            $this->_helper->layout->setLayout('software')
                ->setLayoutPath($this->_site['templatePath'] . '/layouts');

            $viewParams['soft'] = $software;            
            $viewParams['platform'] = $this->_getPlatform();

            // Insert download stat
            $os = $this->_getOS($_SERVER['HTTP_USER_AGENT']);
            $browser = $this->_getBrowser($_SERVER['HTTP_USER_AGENT']);
            $ip = $this->_getClientIP();
            $country = '';
            
            $this->models['software']->incrementDownloads($uri);
            
            $url = $this->_site['apiUrl'] . 'init' .
                '?portal='. $this->_site['id'] .
                '&ip='. $ip .
                '&uri='. $uri .
                '&country='. $country .
                '&os='. $os .
                '&browser='. $browser .
                '&channel='. $channel .
                '&keyword='. $keyword .
                '&campaign='. $campaign;

            //Llamada a la api de BO para las estadísticas
            $this->_curl(str_replace(" ", "%20", $url));
            $this->view->hotSoftware = $hotSoftware;
            $this->view->newSoftware = $newSoftware;
        } else {
            $this->view->headTitle($this->_site['name']);
            $this->_helper->layout->setLayout('home')
                ->setLayoutPath($this->_site['templatePath'] . '/layouts');
            $this->render('not-found');
        }

        $viewParams['headerBanner'] = $this->models['banner']->getBanner('download-header');
        $viewParams['footerBanner'] = $this->models['banner']->getBanner('download-footer');
        $viewParams['site'] = $this->_site;
        $viewParams['pages'] = $this->models['content']->getPages();

        foreach($viewParams as $key => $val)
            $this->view->$key = $val;
    }

    public function thankYouAction(){
        $uri  = $this->getParam('uri', '');
        $page = $this->getParam('page', 1);

        $viewParams = array(
            'pages' => $this->models['content']->getPages(),
            'categories' => $this->models['category']->getCategories(),
            'terms' => $this->models['search']->getSearchCloud($this->_site['limit']),
            'topDownloads' => $this->models['software']->getTopDownloads($this->_site['limit']),
            'urlSite' => $this->view->baseUrl(),
            'rightBanner' => $this->models['banner']->getBanner('thankyou-right-top'),
            'rightBottomBanner' => $this->models['banner']->getBanner('thankyou-right-bottom'),
            'headerBanner' => $this->models['banner']->getBanner('thankyou-header'),
            'footerBanner' => $this->models['banner']->getBanner('thankyou-footer'),
            'leftBottomBanner' => $this->models['banner']->getBanner('thankyou-left-bottom'),
            'site' => $this->_site
            );

        foreach($viewParams as $key => $val)
            $this->view->$key = $val;

        $software = $this->models['software']->getSoftwareByUri($uri);

        if (is_object($software)) {
            // Set the title
            $this->view->headTitle()->setSeparator(' - ');
            $this->view->headTitle($software->name);
            $this->view->headTitle($this->_site['name']);

  
                $list = $this->models['software']->getSoftwareByCategory(
                    $software->idcategory,
                    $this->_site['limit'],
                    $software->codSoftware
                );
    
            $this->view->software = $software;
        } else {
            $list = $this->models['software']->getSoftwareByHot(1, 5);
            $this->_helper->viewRenderer('thank-you-generic');
            $this->view->headTitle($this->_site['name']);
        }

        $paginator = Zend_Paginator::factory((array)$list);
        $paginator->setItemCountPerPage($this->_site['limit']);
        $paginator->setCurrentPageNumber($page);

        $this->_helper->layout->setLayout('home')
            ->setLayoutPath($this->_site['templatePath'] . '/layouts');

        $this->view->paginator = $paginator;
    }
   

    private function getCapture( $id )
    {
        $urlIcon = 'img/capture/default.png';
        if (file_exists('img/capture/'.$id.'.jpg')) {
            $urlIcon = 'img/capture/'.$id.'.jpg';
        }

        if (file_exists('img/capture/'.$id.'.png')) {
            $urlIcon = 'img/capture/'.$id.'.png';
        }

        return $urlIcon;
    }
    
    private function _getOS($userAgent)
    { 
        $osArray = array(
                        '/windows nt 6.3/i'     =>  'Windows 8.1',
                        '/windows nt 6.2/i'     =>  'Windows 8',
                        '/windows nt 6.1/i'     =>  'Windows 7',
                        '/windows nt 6.0/i'     =>  'Windows Vista',
                        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                        '/windows nt 5.1/i'     =>  'Windows XP',
                        '/windows xp/i'         =>  'Windows XP',
                        '/windows nt 5.0/i'     =>  'Windows 2000',
                        '/windows me/i'         =>  'Windows ME',
                        '/win98/i'              =>  'Windows 98',
                        '/win95/i'              =>  'Windows 95',
                        '/win16/i'              =>  'Windows 3.11',
                        '/macintosh|mac os x/i' =>  'Mac OS X',
                        '/mac_powerpc/i'        =>  'Mac OS X', // Mac OS 9
                        '/linux/i'              =>  'Linux',
                        '/ubuntu/i'             =>  'Ubuntu',
                        '/iphone/i'             =>  'iPhone',
                        '/ipod/i'               =>  'iPod',
                        '/ipad/i'               =>  'iPad',
                        '/android/i'            =>  'Android',
                        '/blackberry/i'         =>  'BlackBerry',
                        '/webos/i'              =>  'Mobile'
                    );

        foreach ($osArray as $regex => $value) { 
            if (preg_match($regex, $userAgent)) {
                $osPlatform    =   $value;
            }
        }   

        return $osPlatform;
    }
    
    private function _getPlatform()
    {
        $userAgent = $_SERVER['HTTP_USER_AGENT'];
     
        $osPlatform = "Unknown OS Platform";

        $osArray = array(
                '/windows nt 6.2/i'     =>  'Windows 8',
                '/windows nt 6.1/i'     =>  'Windows 7',
                '/windows nt 6.0/i'     =>  'Windows Vista',
                '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                '/windows nt 5.1/i'     =>  'Windows XP',
                '/windows xp/i'         =>  'Windows XP',
                '/windows nt 5.0/i'     =>  'Windows 2000',
                '/windows me/i'         =>  'Windows ME',
                '/win98/i'              =>  'Windows 98',
                '/win95/i'              =>  'Windows 95',
                '/win16/i'              =>  'Windows 3.11',
                '/macintosh|mac os x/i' =>  'Mac OS X',
                '/mac_powerpc/i'        =>  'Mac OS 9',
                '/linux/i'              =>  'Linux',
                '/ubuntu/i'             =>  'Ubuntu',
                '/iphone/i'             =>  'iPhone',
                '/ipod/i'               =>  'iPod',
                '/ipad/i'               =>  'iPad',
                '/android/i'            =>  'Android',
                '/blackberry/i'         =>  'BlackBerry',
                '/webos/i'              =>  'Mobile',
                '/Kindle/i'             =>  'Kindle',
                '/Silk/i'               =>  'Kindle Fire'
                            );

        foreach ($osArray as $regex => $value) { 
            if (preg_match($regex, $userAgent)) {
                $osPlatform = $value;
            }
        }  

        if ($osPlatform == 'iPad' || 
            $osPlatform == 'iPod' || 
            $osPlatform == 'iPhone' || 
            $osPlatform == 'Android' || 
            $osPlatform == 'Mobile' ||
            $osPlatform == 'BlackBerry' || 
            $osPlatform == 'Kindle' || 
            $osPlatform == 'Kindle Fire') {
            $isMobile = true;
        } else {
            $isMobile = false;
        }

        if ($osPlatform == 'Mac OS X' || $osPlatform == 'Mac OS 9') {
            $isOSX = true;
        } else {
            $isOSX = false;
        }

        return array('isMobile' => $isMobile, 'isOSX' => $isOSX, 'platform' => $osPlatform);
    }

    private function _getBrowser($userAgent)
    {
        $browser = "Unknown Browser";

        $browserArray = array(
            '/msie/i'       =>  'Internet Explorer',
            '/firefox/i'    =>  'Firefox',
            '/safari/i'     =>  'Safari',
            '/chrome/i'     =>  'Chrome',
            '/opera/i'      =>  'Opera',
            '/netscape/i'   =>  'Netscape',
            '/maxthon/i'    =>  'Maxthon',
            '/konqueror/i'  =>  'Konqueror',
            '/mobile/i'     =>  'Handheld Browser'
        );

        foreach ($browserArray as $regex => $value) { 

            if (preg_match($regex, $userAgent)) {
                $browser    =   $value;
            }

        }

        return $browser;

    }
    
    private function _getClientIP()
    {
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if(isset($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if(isset($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';

        return $ipaddress; 
    }

    private function _curl($url)
    {
        $ch = curl_init();  // Initialising cURL
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); // Setting cURL's option to return the webpage data
        $data = curl_exec($ch); // Executing the cURL request and assigning the returned data to the $data variable
        curl_close($ch);    // Closing cURL
        return $data;   // Returning the data from the function
    }
}
