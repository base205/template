<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{

    protected function _initCache()
    {
        $frontend = array(
            'lifetime' => 7200, // Two hours
            'automatic_serialization' => true
        );

        $backend= array(
            'cache_dir' => APPLICATION_PATH . '/../cache',
        );

        $cache = Zend_Cache::factory(
            'core',
            'File',
            $frontend,
            $backend
        );

        Zend_Registry::set('Zend_Cache', $cache);
    }
    
    protected function _initPublicResouces()
    {
        $config = $this->getOptions();
        $tr = new Zend_Translate('array', APPLICATION_PATH . '/languages/' . 
            $config['site']['langCode'] . '.php', $config['site']['langCode']);

        Zend_Registry::set('site', $config['site']);
        Zend_Registry::set('tr', $tr);
        
        $this->bootstrap('db'); // Bootstrap the db resource from configuration
                                // now that you have initialized the db resource, 
                                // you can use your dbtable object
    }

    protected function _initView()
    {
        // Inicializar la vista
        $view = new Zend_View();
        $site = Zend_Registry::get('site');
        $view->tr = Zend_Registry::get('tr');

        $view->addScriptPath($site['templatePath'] . '/scripts');
        $view->addHelperPath($site['templatePath'] . '/helpers');
        
        $view->headTitle()->setAutoEscape(false);

         // Añadir al ViewRenderer
         $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('ViewRenderer');
         $viewRenderer->setView($view);

         // Retorno, de modo que pueda ser almacenada en el arranque (bootstrap)
         return $view;
    }

    protected function _initViewFilter(){
        $site = Zend_Registry::get('site');
        $view = $this->getResource('view');
        $view->addFilterPath($site['templatePath'] . '/filters', 'Portal_View_Filter_')
                ->addFilter('Minify');
    }

    protected function _initRoutes()
    {
        // Routes definitions goes here
        $frontController  = Zend_Controller_Front::getInstance();

        $route = new Zend_Controller_Router_Route(
            ':uri/', array(
                'controller' => 'software',
                'action' => 'view'
            )
        );

        $frontController->getRouter()->addRoute('software', $route);

        $route = new Zend_Controller_Router_Route(
            'content/:uri', array(
                'controller' => 'content',
                'action' => 'page-by-uri'
            )
        );

        $frontController->getRouter()->addRoute('content', $route);

        $route = new Zend_Controller_Router_Route(
            'download/:uri/', array(
                'controller' => 'software',
                'action' => 'download'
            )
        );

        $frontController->getRouter()->addRoute('download', $route);
    }

    protected function _initDocType()
    {
        $this->bootstrap('View');
        $view = $this->getResource('View');
        $view->doctype('HTML5');
        $view->setEncoding('UTF-8');
        return $view;
    }

}
