<?php
class Application_Form_Problems extends Zend_Form
{

    public function init()
    {
        $translator = Zend_Registry::get('tr');
        $this->setAttrib("horizontal", true);

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $this->setName('contact');
        $this->setElementsBelongTo('bootstrap');

        //issue
        $issue = new Zend_Form_Element_Select(
            'issue',
            array(
                'multiOptions' => array(
                    'OPEN' => $translator->translate("I can't open the downloaded file"),
                    'ANTIVIRUS' => $translator->translate("Antivirus issue"),
                    'SYSTEM' => $translator->translate("Operating System's issue"),
                    'ANOTHER' => $translator->translate('Another issue'),
                )
            )
        );
        $issue->setLabel($translator->translate('ISSUE'));

        //message
        $message = new Zend_Form_Element_Textarea('message');
        $message->setLabel($translator->translate('MESSAGE'))
            ->setRequired(true)
            ->setAttrib('cols', 40)
            ->setAttrib('rows', 8)
            ->addFilter('StringTrim')
            ->addValidator('NotEmpty');


        $submit = new Zend_Form_Element_Submit('submit');
        $submit->setAttrib('id', 'submitbutton')
               ->setLabel($translator->translate('SUBMIT'));

        // captcha
        $captcha = new Zend_Form_Element_Captcha(
            'captcha', array(
                'label' => "Please verify you're a human",
                'captcha' => 'Figlet',
                'captchaOptions' => array(
                    'captcha' => 'Figlet',
                    'wordLen' => 4,
                    'timeout' => 300,
                ),
            )
        );

        $this->addElements(
            array(
                $issue,
                $message,
                $captcha,
                $submit
            )
        );
    }
}