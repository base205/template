<?php
class Application_Form_Contact extends Zend_Form
{

    public function init()
    {
        $translator = Zend_Registry::get('tr');
        $this->setAttrib("horizontal", true);

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $this->setName('contact');
        $this->setElementsBelongTo('bootstrap');


        #name
        $name = new Zend_Form_Element_Text('name');
        $name->setLabel($translator->translate('NAME'))
            ->setRequired(true)
            ->addFilter('StripTags')
            ->addFilter('StringTrim');

        #mail
        $mail = new Zend_Form_Element_Text('mail');
        $mail->setLabel($translator->translate('MAIL'))
            ->setRequired(true)
            ->addFilter('StripTags')
            ->addFilter('StringTrim')
            ->addValidator('EmailAddress');

        #subject
        $subject = new Zend_Form_Element_Text('subject');
        $subject->setLabel($translator->translate('SUBJECT'))
            ->setRequired(true)
            ->addFilter('StripTags')
            ->addFilter('StringTrim');

        //message
        $message = new Zend_Form_Element_Textarea('message');
        $message->setLabel($translator->translate('MESSAGE'))
            ->setRequired(true)
            ->setAttrib('cols', 40)
            ->setAttrib('rows', 8)
            ->addFilter('StringTrim')
            ->addValidator('NotEmpty');


        $submit = new Zend_Form_Element_Submit('submit');
        $submit->setAttrib('id', 'submitbutton')
               ->setLabel($translator->translate('SUBMIT'));

        // captcha
      /*  $captcha = new Zend_Form_Element_Captcha(
            'captcha', array(
                'label' => "Please verify you're a human",
                'captcha' => 'Figlet',
                'captchaOptions' => array(
                    'captcha' => 'Figlet',
                    'wordLen' => 4,
                    'timeout' => 300,
                ),
            )
        );*/

        $this->addElements(
            array(
                $name,
                $mail,
                $subject,
                $message,
              //  $captcha,
                $submit
            )
        );
    }
}