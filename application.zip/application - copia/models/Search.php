<?php

class Application_Model_Search
{

    private $_db;

    public function __construct()
    {
        $this->_db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $this->_db->setFetchMode(Zend_Db::FETCH_OBJ);
    }

    public function getSearchCloud($limit = 0)
    {

        if (($searchCloud = Zend_Registry::get('Zend_Cache')->load('search_cloud')) === false) {

            // action body
            $select = $this->_db->select()->from('search', array('word', 'count'));
      
            if ( $limit > 0 ) {
               
                $select->order('count DESC');
                $select->limitPage(0, $limit);
            }

            $list = $this->_db->fetchAll($select);

            $searchCloud = array();

            $max = 0;
            $min = 1000000000;
            foreach ($list as $element) {
                $max = ($max > $element->count) ? $max : $element->count ;
                $min = ($min < $element->count) ? $min : $element->count ;
            }
            if (($max-$min) > 0) {
                foreach ($list as $element) {
                    $tag = ceil($element->count/(($max-$min)/9));
                    $searchCloud[] = array(
                        'word'  => $element->word,
                        'count' => $tag
                    );
                }


                shuffle($searchCloud);
            }

            Zend_Registry::get('Zend_Cache')->save($searchCloud, 'search_cloud');

        }

        return $searchCloud;

    }

}