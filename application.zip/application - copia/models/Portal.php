<?php
class Application_Model_Portal
{

    private $_db;

    public function __construct()
    {
        $this->_db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $this->_db->setFetchMode(Zend_Db::FETCH_OBJ);
    }

    public function getBanner()
    {
        $sql = $this->_db->select()
            ->from('portal', array('mobileMonetization'));

        return $this->_db->fetchRow($sql);

    }

    public function getTitle()
    {
        if (($title = Zend_Registry::get('Zend_Cache')->load('title')) === false) {

            $sql = $this->_db->select()
                ->from('portal', array('title'));
        
            $row = $this->_db->fetchRow($sql);

            if ($row != null) {
                $title = $row->title;
                Zend_Registry::get('Zend_Cache')->save($title, 'title');
            } else {
                $title = '';
            }

        }
        
        return $title;
    }

    public function getAnalytics()
    {
        $sql = $this->_db->select()
            ->from('portal', array('jsAnalytics'));
    
        $row = $this->_db->fetchRow($sql);

        if ($row != null) {
            $jsAnalytics = $row->jsAnalytics;
        } else {
            $jsAnalytics = '';
        }
        
        return $jsAnalytics;
    }

    
}