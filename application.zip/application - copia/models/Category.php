<?php

class Application_Model_Category {

    private $_db;

    public function __construct(){
        $this->_db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $this->_db->setFetchMode(Zend_Db::FETCH_OBJ);
    }

    public function getCategories(){
        if (($categories = Zend_Registry::get('Zend_Cache')->load('categories')) === false) {
            $sql = $this->_db->select()
                    ->from('category', array('idCategory', 'category', 'uri', 'position'))
                    ->where('active = ?', '1')
                    ->order(array('position', 'category'));

            $categories = $this->_db->fetchAll($sql);

            Zend_Registry::get('Zend_Cache')->save($categories, 'categories');
        }

        return $categories;
    }

    public function getCategory($uri){
        $sql = $this->_db->select()
                    ->from('category', array('idCategory', 'category', 'uri', 'position'))
                    ->where('active = ?', '1')
                    ->where('uri = ?', $uri)
                    ->order(array('position','category'));

        return $this->_db->fetchRow($sql);
    }
    
}