<?php
class Application_Model_Software
{

    private $_db;

    public function __construct()
    {
        $this->_db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $this->_db->setFetchMode(Zend_Db::FETCH_OBJ);
    }

    public function getFeatured()
    {
 if (($featured = Zend_Registry::get('Zend_Cache')->load('featured')) === false) {

        $sql = $this->_db->select()
            ->from('software', array('codSoftware','license','name','version','brief','uri'))
            ->where('active = ?', '1')
            ->where('featured = ?', '1')
            ->where('visible = ?', '1');

             $featured = $this->_db->fetchAll($sql);
            Zend_Registry::get('Zend_Cache')->save($featured, 'featured');

        }
        return $featured;
    }

    public function getTopDownloads($limit = 0)
    {
        if (($topDownloads = Zend_Registry::get('Zend_Cache')->load('top_downloads_'.$limit)) === false) {

            $sql = $this->_db->select()
                ->from('software', array('codSoftware','name','uri','rating','brief'))
                ->where('active = ?', '1')
                ->where('visible = ?', '1')
                ->order('downloads');

            if ($limit > 0) {
                $sql->limitPage(0, $limit);
            }

            $topDownloads = $this->_db->fetchAll($sql);
            Zend_Registry::get('Zend_Cache')->save($topDownloads, 'top_downloads_' . $limit);
        }

        return $topDownloads;
    }


   public function getAllActive($limit = 0)
    {
        $sql = $this->_db->select()
            ->from(
                'software', 
                array(
                    'codSoftware',
                    'uri'
                )
            )
            ->where('active = ?', '1')
            ->where('visible = ?', '1');
        
        if ($limit > 0) {
            $sql->limitPage(0, $limit);
        }

        $software = $this->_db->fetchAll($sql);
        return $software;
    }  

    public function getSoftwareByHot($hot = 0, $limit = 0)
    {
        if (($softwareByHot = Zend_Registry::get('Zend_Cache')->load('software_hot_'.$hot.'_'.$limit)) === false) {

            $sql = $this->_db->select()
                ->from(
                    'software', 
                    array(
                        'codSoftware',
                        'license',
                        'developer',
                        'name',
                        'size',
                        'version',
                        'os',
                        'detail',
                        'brief',
                        'featured',
                        'hot',
                        'uri',
                        'exeType',
                        'rating',
                        'developerWeb',
                        'downloads'
                    )
                )
                ->where('active = ?', '1')
                ->where('visible = ?', '1')
                ->where('hot = ?', $hot)
                ->order('downloads');
            
            if ($limit > 0) {
                $sql->limitPage(0, $limit);
            }

            $softwareByHot = $this->_db->fetchAll($sql);
            Zend_Registry::get('Zend_Cache')->save($softwareByHot, 'software_hot_'.$hot.'_'.$limit);
        }
        return $softwareByHot;
    }

    public function getSoftwareByCategory($category, $limit = 0, $exclude = null,$order = null, $hot = 0)
    {
        if (isset($category)) {
            $sql = $this->_db->select()
                ->from(
                    array('s' => 'software'),
                    array('codSoftware', 'name', 'detail', 'rating', 'brief', 'uri', 'rating', 'downloads')
                )
                ->joinInner(array('c' => 'software_category'), 's.codSoftware = c.codSoftware')
                ->where('s.active = ?', '1')
                ->where('s.visible = ?', '1')
                ->where('s.hot = ?', $hot)
                ->where('c.idCategory = ?', $category);

            if ($exclude !== null) {
                $sql->where('s.codSoftware NOT IN (?)', $exclude);
            }

            if ($order != null) {
                switch ($order) {
                    case 'name':
                        $sql->order('s.name');
                        break;
                    case'downloads':
                        $sql->order('s.downloads DESC');
                        break;
                    case'rating':
                        $sql->order('s.rating DESC');
                        break;
                }

            } else {
                $sql->order('s.name');
            }

            if ( $limit > 0 ) {
                $sql->limitPage(0, $limit);
            }

            return $this->_db->fetchAll($sql);
        }

        return array();
    }

    public function getSoftwareByUri($uri)
    {
       $uriCache = str_replace("-","_",$uri);

        if (($softwareByUri = Zend_Registry::get('Zend_Cache')->load('software_uri_'.$uriCache)) === false) {

            $sql = $this->_db->select()
                ->from(
                    array('s' => 'software'),
                    array(
                        's.codSoftware', 
                        's.license', 
                        's.developer', 
                        's.developerWeb', 
                        's.name', 
                        's.size', 
                        's.version', 
                        's.os', 
                        's.detail', 
                        's.brief', 
                        's.downloads', 
                        's.rating', 
                        's.metaDescription', 
                        's.metaKeywords', 
                        's.uri', 
                        's.uri AS softwareUri',
                        's.exeType',
                        's.scriptDownloadPage',
                        's.scriptThankyouPage',
                        's.scriptLandingPage',
                        's.externalBundle',
                        's.externalBundleUrl',
                        'c.idcategory',
                        'c.category',
                        'c.uri AS categoryUri'
                    )
                )
                ->joinLeft(array('sc' => 'software_category'), 's.codSoftware = sc.codSoftware', array())
                ->joinLeft(array('c' => 'category'), 'sc.idCategory = c.idCategory', array())
                ->where('s.active = ?', '1')
                ->where('s.uri = ?', $uri)
                ->limit(1);

            $softwareByUri = $this->_db->fetchRow($sql);
            
            Zend_Registry::get('Zend_Cache')->save($softwareByUri, 'software_uri_'.$uriCache);
        }


        return $softwareByUri;
    }

    public function getCommentsByCod($codSoftware)
    {
        $sql = $this->_db->select()
            ->from('comment', array('user', 'image', 'title', 'comment'))
            ->where('codSoftware = ?', $codSoftware);
        return $this->_db->fetchAll($sql);
    }

    public function search($word,$order=null)
    {
        $sql = $this->_db->select()
            ->from(
                'software',
                array(
                    'codSoftware', 
                    'license', 
                    'developer', 
                    'developerWeb', 
                    'name', 
                    'size', 
                    'version', 
                    'os', 
                    'detail', 
                    'brief', 
                    'featured',
                    'hot',
                    'downloads', 
                    'rating',  
                    'uri', 
                )
            )
            ->where('active = ?', '1')
            ->where('visible = ?', '1')
            ->where("name like '%$word%' OR detail like '%$word%'");

        if ($order != null) {
            switch ($order) {
                case 'name':
                    $sql->order('name');
                    break;
                case'downloads':
                    $sql->order('downloads DESC');
                    break;
                case'rating':
                    $sql->order('rating DESC');
                    break;
            }
        } else {
            $sql->order('name');
        }

        return $this->_db->fetchAll($sql);
    }

    public function saveSearch($word)
    {
        $insert = " INSERT INTO search (word, count) VALUES ('$word', 1)
                    ON DUPLICATE KEY UPDATE count = count + 1";

        $this->_db->query($insert);
    }

    public function incrementDownloads($uri)
    {
        $data = array('downloads' => new Zend_Db_Expr('downloads + 1')); 
        $where[] = "active = 1";
        $where[] = "uri = '$uri'";

        $this->_db->update('software', $data, $where);
    }

    public function getCategoryFromSoftware($codSoftware)
    {

  if (($categoryFromSoftware = Zend_Registry::get('Zend_Cache')->load('category_From_Software')) === false) {
        $sql = $this->_db->select()
            ->from(array('cat' => 'category'), array('cat.idCategory', 'cat.category'))
            ->joinInner(array('sc' => 'software_category'), 'cat.idCategory = sc.idCategory')
            ->where('sc.codSoftware = ?', $codSoftware);

            $categoryFromSoftware = $this->_db->fetchRow($sql);
            Zend_Registry::get('Zend_Cache')->save($categoryFromSoftware, 'category_From_Software');

        }

        return  $categoryFromSoftware;
    }
}