<?php
class Application_Model_Banner
{

    private $_db;

    public function __construct()
    {
        $this->_db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $this->_db->setFetchMode(Zend_Db::FETCH_OBJ);
    }

    public function getBanner($position)
    {
        $positionBanner = str_replace("-","_",$position);
        if (($Banner = Zend_Registry::get('Zend_Cache')->load('Banner_'.$positionBanner)) === false) {
        $sql = $this->_db->select()
            ->from('banner', array('image','action','script'))
            ->where('position = ?', $position);

            $Banner = $this->_db->fetchRow($sql);
            Zend_Registry::get('Zend_Cache')->save($Banner, 'Banner_'.$positionBanner);
        }

        return $Banner;
    }

}
